   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy;Online Library Management System | Designed by : <a href="https://adglob.in/" target="_blank" >Adglob Infosystem Pvt Ltd</a> 
                </div>

            </div>
        </div>
    </section>