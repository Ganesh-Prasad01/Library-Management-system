<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:../adminlogin.php');
}
else{?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Library Management System | Admin Dash Board</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
      <section class="menu-section">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle " data-toggle="collapse" data-target=".navbar-collapse">
                    <i class="fa fa-bars threebar" aria-hidden="true"></i>
                </button>
            </div>
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                           
                            <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Categories <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu dropp" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="add-category.php">Add Category</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-categories.php">Manage Categories</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Authors <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu dropp" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="add-author.php">Add Author</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-authors.php">Manage Authors</a></li>
                                </ul>
                            </li>
 <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Books <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu dropp" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="add-book.php">Add Book</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-books.php">Manage Books</a></li>
                                </ul>
                            </li>

                           <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Issue Books <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu dropp" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="issue-book.php">Issue New Book</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-issued-books.php">Manage Issued Books</a></li>
                                </ul>
                            </li>
                             <li><a href="reg-students.php">Reg Students</a></li>
                    
                         <li><a href="change-password.php">Change Password</a></li>
                         <li><a href="logout.php" class="log" style="font-weight: bold; background: #ff8e41; font-weight: bold; color: #02151f;"><i class="glyphicon glyphicon-log-out" aria-hidden="true"></i>&nbsp;Logout</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php 
// include('includes/header.php');
?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <div class="header-line">
                        <p style=" background-image: url('assets/img/ag.jpg');
                                   background-repeat: repeat;
                                    -webkit-background-clip: text;
                                    -webkit-text-fill-color: transparent;
                                    /*margin-top: 200px;*/
                                    font-size: 30px;
                                    text-align: center;
                                    font-weight: bold;
                                    text-transform: uppercase;
                                    font-family: 'Steelfish Rg', 'helvetica neue',
                                                helvetica, arial, sans-serif;
                                    font-weight: 800;
                                    -webkit-font-smoothing: antialiased;" >ADMIN DASHBOARD</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert  back-widget-set text-center innercontent">
                        <i class="fa fa-book fa-5x"></i>
                        <?php 
                        $sql ="SELECT id from tblbooks ";
                        $query = $dbh -> prepare($sql);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        $listdbooks=$query->rowCount();
                        ?>

                        <h3><?php echo htmlentities($listdbooks);?></h3>
                        Books Listed
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert  back-widget-set text-center innercontent">
                        <i class="fa fa-bars fa-5x"></i>
                        <?php 
                        $sql1 ="SELECT id from tblissuedbookdetails ";
                        $query1 = $dbh -> prepare($sql1);
                        $query1->execute();
                        $results1=$query1->fetchAll(PDO::FETCH_OBJ);
                        $issuedbooks=$query1->rowCount();
                        ?>

                        <h3><?php echo htmlentities($issuedbooks);?> </h3>
                           Times Book Issued
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert  back-widget-set text-center innercontent">
                        <i class="fa fa-recycle fa-5x"></i>
                        <?php 
                        $status=1;
                        $sql2 ="SELECT id from tblissuedbookdetails where RetrunStatus=:status";
                        $query2 = $dbh -> prepare($sql2);
                        $query2->bindParam(':status',$status,PDO::PARAM_STR);
                        $query2->execute();
                        $results2=$query2->fetchAll(PDO::FETCH_OBJ);
                        $returnedbooks=$query2->rowCount();
                        ?>
                        <h3><?php echo htmlentities($returnedbooks);?></h3>
                        Books Returned
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert  back-widget-set text-center innercontent">
                        <i class="fa fa-users fa-5x"></i>
                        <?php 
                        $sql3 ="SELECT id from tblstudents ";
                        $query3 = $dbh -> prepare($sql1);
                        $query3->execute();
                        $results3=$query3->fetchAll(PDO::FETCH_OBJ);
                        $regstds=$query3->rowCount();
                        ?>
                        <h3><?php echo htmlentities($regstds);?></h3>
                           Registered Users
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert alert-success back-widget-set text-center innercontent">
                        <i class="fa fa-user fa-5x"></i>
                        <?php 
                        $sq4 ="SELECT id from tblauthors ";
                        $query4 = $dbh -> prepare($sql);
                        $query4->execute();
                        $results4=$query4->fetchAll(PDO::FETCH_OBJ);
                        $listdathrs=$query4->rowCount();
                        ?>
                        <h3><?php echo htmlentities($listdathrs);?></h3>
                         Authors Listed
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert alert-info back-widget-set text-center innercontent">
                        <i class="fa fa-file-archive-o fa-5x"></i>
                        <?php 
                        $sql5 ="SELECT id from tblcategory ";
                        $query5 = $dbh -> prepare($sql1);
                        $query5->execute();
                        $results5=$query5->fetchAll(PDO::FETCH_OBJ);
                        $listdcats=$query5->rowCount();
                        ?>
                        <h3><?php echo htmlentities($listdcats);?> </h3>
                        Listed Categories
                    </div>
                </div>
            </div>
                        
            <div class="row" style="margin-bottom: 15px;">
                <div class="col-md-10 col-sm-8 col-xs-12 col-md-offset-1">
                    <div id="carousel-example" class="carousel slide slide-bdr" data-ride="carousel" >
                        <div class="carousel-inner">
                            <div class="item active">
                                <img src="assets/img/3.jpg" alt="" />
                            </div>
                            <div class="item">
                                <img src="assets/img/3.jpg" alt="" />
                            </div>
                            <div class="item">
                                <img src="assets/img/3.jpg" alt="" /> 
                            </div>
                        </div>
                        <!--INDICATORS-->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example" data-slide-to="1"></li>
                            <li data-target="#carousel-example" data-slide-to="2"></li>
                        </ol>
                        <!--PREVIUS-NEXT BUTTONS-->
                        <a class="left carousel-control" href="#carousel-example" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        </a>
                    </div>
                </div>
            </div>    
        </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
<?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
